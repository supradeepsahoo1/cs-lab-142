#include <iostream>
#include <cmath>

using namespace std;

int main ()
{ float d;
  cout << "enter number of days = ";
  cin >> d;
  cout << "conversion into years is = " << d/365<< endl;
  cout << "conversion into weeks is = " << d/7 ;
  return 0;
}

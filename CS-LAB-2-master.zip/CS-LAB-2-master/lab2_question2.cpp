#include <iostream>
using namespace std;

int main() { float c;
  cout << "enter the temperature in celsius = ";
  cin >> c;
  cout << "your temperature in fehrenheit = " << (9*c/5)+32;
	return 0;
}

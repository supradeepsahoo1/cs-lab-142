#include <iostream>
#include <cmath>
using namespace std;

int main()
{
 float p, r, t;
 cout << "enter P,T & R to calculate your simple interest" << endl;
 cin >> p>>r>>t;
 cout << "the simple interest is = "<< (p*r*t)/100;



    return 0;
}

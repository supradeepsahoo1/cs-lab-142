#include <iostream>
#include <cmath>

using namespace std;

int main ()
{ float b, h;
  cout << "enter the base and height of a triangle respectively"<<endl;
  cin >> b >> h;
  cout << "the area of the triangle is = " << (h*b)/2;
  return 0;
}

#include <iostream>
#include <cmath>

using namespace std;

int main ()
{ int x, y;
  cout<< "enter your base"<< endl;
 cin >> x;
  cout << "enter your exponent" << endl;
  cin >> y;
  cout <<"your answer is " << pow(x,y);
  return 0;
}

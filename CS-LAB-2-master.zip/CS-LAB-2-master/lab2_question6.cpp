#include <iostream>
#include <cmath>

using namespace std;

int main ()
{ float x;
  cout<< "enter your number"<< endl;
  cin >> x;
  cout <<"squareroot of the number is " << sqrt(x);
  return 0;
}
